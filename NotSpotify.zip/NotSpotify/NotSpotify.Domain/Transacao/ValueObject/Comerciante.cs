﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotSpotify.Domain.Transacao.ValueObject
{
    public class Comerciante
    {
        public string Nome { get; set; }
    }
}
