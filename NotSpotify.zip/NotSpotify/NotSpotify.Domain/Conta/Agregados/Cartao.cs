﻿using NotSpotify.Domain.Conta.Excecao;
using NotSpotify.Domain.Transacao.Agregados;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotSpotify.Domain.Conta.Agregados
{
    public class Cartao
    {

        private const int TRANSACTION_TIME_INTERVAL = -2;
        private const int TRANSACTION_MERCHANT_REPEAT = 1;

        public Guid Id { get; set; }
        public Boolean Ativo { get; set; }
        public Decimal Limite { get; set; }
        public String Numero { get; set; }
        public List<Transacao.Agregados.Transacao> Transacoes { get; set; }

        public Cartao()
        {
            this.Transacoes = new List<Transacao.Agregados.Transacao>();
        }

        public void CriarTransacao(string merchant, Decimal valor, string descricao)
        {
            CartaoException validationErrors = new CartaoException();

            //Verificar se o cartao está ativo
            this.IsCartaoAtivo(validationErrors);

            Transacao.Agregados.Transacao transacao = new Transacao.Agregados.Transacao();
            transacao.Comerciante = new Transacao.ValueObject.Comerciante() { Nome = merchant };
            transacao.Valor = valor;
            transacao.Descricao = descricao;
            transacao.DtTransacao = DateTime.Now;

            //Verificar o Limite
            this.VerificaLimiteDisponivel(transacao, validationErrors);

            //Validar a transação
            this.ValidarTransacao(transacao, validationErrors);

            //Verifica senão ocorreu erros de validação
            validationErrors.ValidateAndThrow();

            //Criar numero de Autorização
            transacao.Id = Guid.NewGuid();

            //Diminui o limite com o valor da transação
            this.Limite = this.Limite - transacao.Valor;

            //Adicionar uma nova transação
            this.Transacoes.Add(transacao);


        }

        private void IsCartaoAtivo(CartaoException validationErrors)
        {
            if (this.Ativo == false)
            {
                validationErrors.AddError(new Core.Excecao.BusinessValidation()
                {
                    ErrorMessage = "Esse cartão não está ativo.",
                    ErrorName = nameof(CartaoException)
                });

            }

        }

        private void VerificaLimiteDisponivel(Transacao.Agregados.Transacao transacao, CartaoException validationErrors)
        {
            if (transacao.Valor > this.Limite)
            {
                validationErrors.AddError(new Core.Excecao.BusinessValidation()
                {
                    ErrorMessage = "Não é possível realizar essa compra com o atual limite desse cartão.",
                    ErrorName = nameof(CartaoException)
                });
            }
        }

        private void ValidarTransacao(Transacao.Agregados.Transacao transacao, CartaoException validationErrors)
        {
            var ultimasTransacoes = this.Transacoes.Where(x => x.DtTransacao >= DateTime.Now.AddMinutes(TRANSACTION_TIME_INTERVAL));

            if (ultimasTransacoes?.Count() >= 3)
            {
                validationErrors.AddError(new Core.Excecao.BusinessValidation()
                {
                    ErrorMessage = "Esse cartão foi utilizado muitas vezes em um período curto de tempo.",
                    ErrorName = nameof(CartaoException)
                });
            }

            if (ultimasTransacoes?.Where(x => x.Comerciante.Nome.ToUpper() == transacao.Comerciante.Nome.ToUpper()
                                         && x.Valor == transacao.Valor).Count() == TRANSACTION_MERCHANT_REPEAT)
            {
                validationErrors.AddError(new Core.Excecao.BusinessValidation()
                {
                    ErrorMessage = "Muitas transações foram feitas com esse comerciante em um período curto de tempo.",
                    ErrorName = nameof(CartaoException)
                });
            }
        }
    }
}
