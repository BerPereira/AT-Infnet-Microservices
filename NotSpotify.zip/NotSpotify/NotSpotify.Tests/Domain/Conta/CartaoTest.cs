﻿using NotSpotify.Domain.Conta.Agregados;
using NotSpotify.Domain.Conta.Excecao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotSpotify.Tests.Domain.Conta
{
    public class CartaoTest
    {
        [Fact]
        public void DeveCriarTransacaoComSucesso()
        {
            Cartao cartao = new Cartao()
            {
                Id = Guid.NewGuid(),
                Ativo = true,
                Limite = 1000M,
                Numero = "6465465466",
            };

            cartao.CriarTransacao("Teste", 19M, "Transacao Teste");
            Assert.True(cartao.Transacoes.Count > 0);
        }

        [Fact]
        public void NaoDeveCriarTransacaoComCartaoInativo()
        {
            Cartao cartao = new Cartao()
            {
                Id = Guid.NewGuid(),
                Ativo = false,
                Limite = 1000M,
                Numero = "6465465466",
            };

            Assert.Throws<CartaoException>(
                () => cartao.CriarTransacao("Teste", 19M, "Transacao Teste"));
        }

        [Fact]
        public void NaoDeveCriarTransacaoComCartaoSemLimite()
        {
            Cartao cartao = new Cartao()
            {
                Id = Guid.NewGuid(),
                Ativo = true,
                Limite = 10M,
                Numero = "6465465466",
            };

            Assert.Throws<CartaoException>(
                () => cartao.CriarTransacao("Teste", 19M, "Transacao Teste"));
        }

        [Fact]
        public void NaoDeveCriarTransacaoComCartaoValorDuplicado()
        {
            Cartao cartao = new Cartao()
            {
                Id = Guid.NewGuid(),
                Ativo = true,
                Limite = 1000M,
                Numero = "6465465466",
            };

            cartao.Transacoes.Add(new NotSpotify.Domain.Transacao.Agregados.Transacao()
            {
                DtTransacao = DateTime.Now,
                Id = Guid.NewGuid(),
                Comerciante = new NotSpotify.Domain.Transacao.ValueObject.Comerciante()
                {
                    Nome = "Teste"
                },
                Valor = 19M,
                Descricao = "Lorem ipsum"
            });

            Assert.Throws<CartaoException>(
                () => cartao.CriarTransacao("Teste", 19M, "Transacao Teste"));
        }

        [Fact]
        public void NaoDeveCriarTransacaoComCartaoAltoFrequencia()
        {
            Cartao cartao = new Cartao()
            {
                Id = Guid.NewGuid(),
                Ativo = true,
                Limite = 1000M,
                Numero = "6465465466",
            };

            cartao.Transacoes.Add(new NotSpotify.Domain.Transacao.Agregados.Transacao()
            {
                DtTransacao = DateTime.Now.AddMinutes(-1),
                Id = Guid.NewGuid(),
                Comerciante = new NotSpotify.Domain.Transacao.ValueObject.Comerciante()
                {
                    Nome = "Teste"
                },
                Valor = 19M,
                Descricao = "Lorem ipsum"
            });

            cartao.Transacoes.Add(new NotSpotify.Domain.Transacao.Agregados.Transacao()
            {
                DtTransacao = DateTime.Now.AddMinutes(-0.5),
                Id = Guid.NewGuid(),
                Comerciante = new NotSpotify.Domain.Transacao.ValueObject.Comerciante()
                {
                    Nome = "Teste"
                },
                Valor = 19M,
                Descricao = "Lorem ipsum"
            });

            cartao.Transacoes.Add(new NotSpotify.Domain.Transacao.Agregados.Transacao()
            {
                DtTransacao = DateTime.Now,
                Id = Guid.NewGuid(),
                Comerciante = new NotSpotify.Domain.Transacao.ValueObject.Comerciante()
                {
                    Nome = "Teste"
                },
                Valor = 19M,
                Descricao = "Lorem ipsum"
            });


            Assert.Throws<CartaoException>(
                () => cartao.CriarTransacao("Teste", 19M, "Transacao Teste"));
        }
    }
}
