﻿using NotSpotify.Streaming.Domain.Agregados;
using NotSpotify.Streaming.Domain.ValueObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotSpotify.Streaming.Domain.Agregados
{
    public class Musica
    {
        public Guid Id { get; set; }
        public string Nome { get; set; }
        public Duracao Duracao { get; set; }
        public Album Album { get; set; }
    }
}
